using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Per-enemy navigation state and waypoint follower.
///
/// Path computation belongs to the shared EnemyPathService and physical
/// movement belongs to EnemyMotor2D. This agent only owns request timing,
/// destination changes, waypoint progress and stuck recovery.
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(EnemyPathfinder))]
[RequireComponent(typeof(EnemyMotor2D))]
public sealed class EnemyNavigationAgent : MonoBehaviour
{
    [Header("EA3 navigation settings")]
    [SerializeField] private float waypointTolerance = 0.035f;
    [SerializeField] private float stopDistance = 0.72f;
    [SerializeField] private float lastPositionTolerance = 0.15f;

    [Min(0.02f)]
    [SerializeField] private float minimumRepathInterval = 0.08f;

    [Min(0.1f)]
    [SerializeField] private float stuckTimeout = 0.75f;

    [Min(0.001f)]
    [SerializeField] private float stuckMovementThreshold = 0.015f;

    [Range(1, 8)]
    [SerializeField] private int maximumRecoveryAttempts = 3;

    [Min(0.05f)]
    [SerializeField] private float maximumRecoverySnapDistance = 0.8f;

    [Min(0.05f)]
    [SerializeField] private float failedRequestRetryDelay = 0.5f;

    [Tooltip(
        "EA3 keeps the accepted chase distance behaviour. The Definition's " +
        "future chase-cost limit is activated with EA4 behaviour rules.")]
    [SerializeField] private int maximumPathCostInCells;

    [Header("Runtime references")]
    [SerializeField] private EnemyRuntimeContext context;
    [SerializeField] private EnemyPathService pathService;
    [SerializeField] private EnemyPathfinder pathfinder;
    [SerializeField] private EnemyMotor2D motor;

    [Header("Runtime request snapshot")]
    [SerializeField] private bool initialized;
    [SerializeField] private EnemyNavigationStatus navigationStatus =
        EnemyNavigationStatus.Uninitialized;

    [SerializeField] private bool hasDesiredDestination;
    [SerializeField] private Vector2 desiredDestination;
    [SerializeField] private bool hasKnownTargetCell;
    [SerializeField] private Vector2Int knownTargetCell;
    [SerializeField] private bool hasQueuedRepath;
    [SerializeField] private bool waitingAtWaypointForRepath;
    [SerializeField] private bool pathRequestPending;
    [SerializeField] private int pendingRequestId;
    [SerializeField] private float nextAllowedRepathAt;
    [SerializeField] private float retryFailedRequestAt;

    [Header("Runtime path snapshot")]
    [SerializeField] private int currentPathCount;
    [SerializeField] private int pathIndex;
    [SerializeField] private bool hasCurrentWaypoint;
    [SerializeField] private Vector2 currentWaypoint;
    [SerializeField] private int lastPathCost;
    [SerializeField] private int lastExpandedNodeCount;

    [Header("Runtime failure and recovery snapshot")]
    [SerializeField] private EnemyPathFailureReason lastFailureReason;
    [SerializeField] private string lastFailureDetails = string.Empty;
    [SerializeField] private float noProgressDuration;
    [SerializeField] private bool isStuck;
    [SerializeField] private int recoveryAttemptCount;
    [SerializeField] private int totalRecoveryCount;
    [SerializeField] private int submittedRequestCount;
    [SerializeField] private int acceptedPathCount;
    [SerializeField] private int failedPathCount;

    [Header("Optional diagnostics")]
    [SerializeField] private bool showPathGizmos = true;

    private Rigidbody2D body;
    private Transform target;
    private EnemyDetection detection;
    private readonly List<Vector2> currentPath =
        new List<Vector2>();

    private Vector2 progressReferencePosition;
    private bool movementExpectedLastTick;
    private Vector2Int pendingGoalCell;

    public bool IsInitialized => initialized;
    public EnemyRuntimeContext Context => context;
    public EnemyPathService PathService => pathService;
    public EnemyPathfinder Pathfinder => pathfinder;
    public EnemyMotor2D Motor => motor;
    public EnemyNavigationStatus NavigationStatus => navigationStatus;
    public bool HasActivePath => pathIndex < currentPath.Count;
    public int RemainingWaypointCount => HasActivePath
        ? currentPath.Count - pathIndex
        : 0;

    public bool IsPathRequestPending => pathRequestPending;
    public int PendingRequestId => pendingRequestId;
    public bool HasQueuedRepath => hasQueuedRepath;
    public EnemyPathFailureReason LastFailureReason => lastFailureReason;
    public string LastFailureDetails => lastFailureDetails;
    public bool IsStuck => isStuck;
    public float NoProgressDuration => noProgressDuration;
    public int RecoveryAttemptCount => recoveryAttemptCount;
    public int TotalRecoveryCount => totalRecoveryCount;
    public int SubmittedRequestCount => submittedRequestCount;
    public int AcceptedPathCount => acceptedPathCount;
    public int FailedPathCount => failedPathCount;

    private void Awake()
    {
        CacheComponents();
    }

    public void Initialize(
        EnemyRuntimeContext newContext,
        EnemyPathService newPathService,
        EnemyPathfinder newPathfinder,
        EnemyMotor2D newMotor,
        float newWaypointTolerance,
        float newStopDistance,
        float newLastPositionTolerance,
        float newMinimumRepathInterval,
        float newStuckTimeout,
        float newStuckMovementThreshold,
        int newMaximumRecoveryAttempts,
        float newMaximumRecoverySnapDistance,
        float newFailedRequestRetryDelay,
        int newMaximumPathCostInCells)
    {
        CancelPendingRequest();

        context = newContext;
        pathService = newPathService;
        pathfinder = newPathfinder;
        motor = newMotor;
        CacheComponents();

        target = context != null
            ? context.CurrentTarget
            : null;

        if (context != null)
        {
            body = context.Body;
            detection = context.Detection;
        }

        ApplySettings(
            newWaypointTolerance,
            newStopDistance,
            newLastPositionTolerance,
            newMinimumRepathInterval,
            newStuckTimeout,
            newStuckMovementThreshold,
            newMaximumRecoveryAttempts,
            newMaximumRecoverySnapDistance,
            newFailedRequestRetryDelay,
            newMaximumPathCostInCells);

        ResetNavigationState();

        initialized =
            context != null &&
            context.IsInitialized &&
            pathService != null &&
            pathService.IsInitialized &&
            pathfinder != null &&
            motor != null &&
            motor.IsInitialized &&
            body != null &&
            target != null &&
            detection != null;

        navigationStatus = initialized
            ? EnemyNavigationStatus.Idle
            : EnemyNavigationStatus.Uninitialized;
    }

    public void ApplySettings(
        float newWaypointTolerance,
        float newStopDistance,
        float newLastPositionTolerance,
        float newMinimumRepathInterval,
        float newStuckTimeout,
        float newStuckMovementThreshold,
        int newMaximumRecoveryAttempts,
        float newMaximumRecoverySnapDistance,
        float newFailedRequestRetryDelay,
        int newMaximumPathCostInCells)
    {
        waypointTolerance = Mathf.Clamp(
            newWaypointTolerance,
            0.001f,
            0.25f);

        stopDistance = Mathf.Max(0f, newStopDistance);
        lastPositionTolerance = Mathf.Clamp(
            newLastPositionTolerance,
            0.01f,
            1f);

        minimumRepathInterval = Mathf.Max(
            0.02f,
            newMinimumRepathInterval);

        stuckTimeout = Mathf.Max(0.1f, newStuckTimeout);
        stuckMovementThreshold = Mathf.Max(
            0.001f,
            newStuckMovementThreshold);

        maximumRecoveryAttempts = Mathf.Clamp(
            newMaximumRecoveryAttempts,
            1,
            8);

        maximumRecoverySnapDistance = Mathf.Max(
            0.05f,
            newMaximumRecoverySnapDistance);

        failedRequestRetryDelay = Mathf.Max(
            0.05f,
            newFailedRequestRetryDelay);

        maximumPathCostInCells = Mathf.Max(
            0,
            newMaximumPathCostInCells);
    }

    public void ApplyLegacyMovementSettings(
        float newWaypointTolerance,
        float newStopDistance,
        float newLastPositionTolerance)
    {
        waypointTolerance = Mathf.Clamp(
            newWaypointTolerance,
            0.001f,
            0.25f);

        stopDistance = Mathf.Max(0f, newStopDistance);
        lastPositionTolerance = Mathf.Clamp(
            newLastPositionTolerance,
            0.01f,
            1f);
    }

    public void ObserveDetectedTarget(Vector2 observedPosition)
    {
        if (!initialized)
        {
            return;
        }

        context.SetLastKnownTargetPosition(observedPosition);
        desiredDestination = observedPosition;
        hasDesiredDestination = true;
        context.SetNavigationDestination(observedPosition);

        Vector2Int targetCell =
            pathService.WorldToCell(observedPosition);

        if (hasKnownTargetCell &&
            targetCell == knownTargetCell)
        {
            return;
        }

        knownTargetCell = targetCell;
        hasKnownTargetCell = true;
        hasQueuedRepath = true;

        if (pathRequestPending && !HasActivePath)
        {
            CancelPendingRequest();
        }
    }

    public void TickFixed(EnemyRuntimeState state)
    {
        if (!initialized)
        {
            return;
        }

        if (state != EnemyRuntimeState.Chase &&
            state !=
                EnemyRuntimeState.InvestigateLastKnownPosition)
        {
            motor.Stop();
            ResetProgressTracking();
            navigationStatus = EnemyNavigationStatus.Idle;
            return;
        }

        if (EvaluateMovementProgressAndRecover())
        {
            return;
        }

        if (detection.IsTargetDetected &&
            Vector2.Distance(
                body.position,
                target.position) <= stopDistance)
        {
            motor.Stop();
            ResetProgressTracking();
            navigationStatus = EnemyNavigationStatus.Stopped;
            return;
        }

        if (!context.HasLastKnownTargetPosition)
        {
            motor.Stop();
            ResetProgressTracking();
            navigationStatus = EnemyNavigationStatus.Idle;
            return;
        }

        EnsureDesiredDestinationFromContext();

        if (navigationStatus == EnemyNavigationStatus.Failed &&
            Time.time < retryFailedRequestAt)
        {
            motor.Stop();
            return;
        }

        if (pathRequestPending)
        {
            motor.Stop();
            navigationStatus = EnemyNavigationStatus.WaitingForPath;
            return;
        }

        if (waitingAtWaypointForRepath || !HasActivePath)
        {
            if (ShouldMoveDirectlyWithinGoalCell())
            {
                MoveDirectlyWithinGoalCell();
                return;
            }

            if (hasQueuedRepath || !HasActivePath)
            {
                TrySubmitPathRequest();
                return;
            }
        }

        if (HasActivePath)
        {
            FollowCurrentWaypoint();
            return;
        }

        motor.Stop();
        navigationStatus = EnemyNavigationStatus.Idle;
    }

    public void StopMovement(bool clearLastKnownPosition)
    {
        CancelPendingRequest();
        currentPath.Clear();
        pathIndex = 0;
        hasCurrentWaypoint = false;
        currentWaypoint = Vector2.zero;
        hasDesiredDestination = false;
        hasKnownTargetCell = false;
        hasQueuedRepath = false;
        waitingAtWaypointForRepath = false;
        isStuck = false;
        recoveryAttemptCount = 0;
        motor.Stop();
        ResetProgressTracking();

        if (context != null)
        {
            context.ClearNavigationDestination();

            if (clearLastKnownPosition)
            {
                context.ClearLastKnownTargetPosition();
            }
        }

        navigationStatus = EnemyNavigationStatus.Idle;
        RefreshPathSnapshot();
    }

    private void EnsureDesiredDestinationFromContext()
    {
        if (!context.HasLastKnownTargetPosition)
        {
            return;
        }

        Vector2 rememberedPosition =
            context.LastKnownTargetPosition;

        if (!hasDesiredDestination)
        {
            desiredDestination = rememberedPosition;
            hasDesiredDestination = true;
            context.SetNavigationDestination(
                rememberedPosition);
        }

        if (!hasKnownTargetCell)
        {
            knownTargetCell =
                pathService.WorldToCell(rememberedPosition);

            hasKnownTargetCell = true;
            hasQueuedRepath = true;
        }
    }

    private bool ShouldMoveDirectlyWithinGoalCell()
    {
        return hasDesiredDestination &&
               pathService.AreInSameCell(
                   body.position,
                   desiredDestination);
    }

    private void MoveDirectlyWithinGoalCell()
    {
        hasQueuedRepath = false;
        waitingAtWaypointForRepath = false;

        Vector2 destination = detection.IsTargetDetected
            ? (Vector2)target.position
            : context.LastKnownTargetPosition;

        float distance = Vector2.Distance(
            body.position,
            destination);

        if (distance <= lastPositionTolerance)
        {
            motor.Stop();
            ResetProgressTracking();

            if (!detection.IsTargetDetected)
            {
                StopMovement(clearLastKnownPosition: true);
            }
            else
            {
                navigationStatus = EnemyNavigationStatus.Stopped;
            }

            return;
        }

        navigationStatus = EnemyNavigationStatus.DirectMovement;
        movementExpectedLastTick = true;
        motor.MoveTowards(destination, lastPositionTolerance);
    }

    private void TrySubmitPathRequest()
    {
        if (!hasDesiredDestination)
        {
            navigationStatus = EnemyNavigationStatus.Idle;
            return;
        }

        if (Time.time < nextAllowedRepathAt)
        {
            motor.Stop();
            navigationStatus =
                EnemyNavigationStatus.WaitingForRepathWindow;

            return;
        }

        EnemyPathFailureReason rejectionReason;
        string rejectionDetails;
        int requestId;

        bool accepted = pathService.TryRequestPath(
            this,
            body.position,
            desiredDestination,
            maximumPathCostInCells,
            HandlePathResult,
            out requestId,
            out rejectionReason,
            out rejectionDetails);

        nextAllowedRepathAt =
            Time.time + minimumRepathInterval;

        if (!accepted)
        {
            RegisterFailure(
                rejectionReason,
                rejectionDetails);

            return;
        }

        pendingRequestId = requestId;
        pendingGoalCell = knownTargetCell;
        pathRequestPending = true;
        hasQueuedRepath = false;
        waitingAtWaypointForRepath = false;
        submittedRequestCount++;
        navigationStatus = EnemyNavigationStatus.WaitingForPath;
        motor.Stop();
    }

    private void HandlePathResult(EnemyPathResult result)
    {
        if (!initialized || result == null ||
            result.RequestId != pendingRequestId)
        {
            return;
        }

        pathRequestPending = false;
        pendingRequestId = 0;
        lastPathCost = result.PathCost;
        lastExpandedNodeCount = result.ExpandedNodeCount;

        if (hasKnownTargetCell &&
            pendingGoalCell != knownTargetCell)
        {
            hasQueuedRepath = true;
            waitingAtWaypointForRepath = true;
            navigationStatus =
                EnemyNavigationStatus.WaitingForRepathWindow;

            return;
        }

        if (!result.Success)
        {
            failedPathCount++;
            RegisterFailure(
                result.FailureReason,
                result.Details);

            return;
        }

        if (result.StartCellAdjusted)
        {
            Vector2 resolvedStartPosition =
                pathService.CellToWorld(
                    result.ResolvedStartCell);

            float recoveryDistance = Vector2.Distance(
                body.position,
                resolvedStartPosition);

            if (recoveryDistance >
                maximumRecoverySnapDistance)
            {
                RegisterFailure(
                    EnemyPathFailureReason.RecoveryDistanceExceeded,
                    "Adjusted start cell is " + recoveryDistance +
                    " world units away; recovery snap was rejected.");

                return;
            }

            motor.SnapToRecoveryCell(resolvedStartPosition);
            totalRecoveryCount++;
        }

        currentPath.Clear();

        for (int i = 0; i < result.WorldPath.Count; i++)
        {
            currentPath.Add(result.WorldPath[i]);
        }

        pathIndex = 0;
        acceptedPathCount++;
        lastFailureReason = EnemyPathFailureReason.None;
        lastFailureDetails = string.Empty;
        retryFailedRequestAt = 0f;
        isStuck = false;
        waitingAtWaypointForRepath = false;
        navigationStatus = HasActivePath
            ? EnemyNavigationStatus.FollowingPath
            : EnemyNavigationStatus.DirectMovement;

        RefreshPathSnapshot();
    }

    private void FollowCurrentWaypoint()
    {
        Vector2 waypoint = currentPath[pathIndex];
        navigationStatus = EnemyNavigationStatus.FollowingPath;
        movementExpectedLastTick = true;

        bool reachedWaypoint = motor.MoveTowards(
            waypoint,
            waypointTolerance);

        if (!reachedWaypoint)
        {
            RefreshPathSnapshot();
            return;
        }

        pathIndex++;

        if (hasQueuedRepath)
        {
            waitingAtWaypointForRepath = true;
            motor.Stop();
            RefreshPathSnapshot();
            return;
        }

        if (!HasActivePath)
        {
            waitingAtWaypointForRepath = false;
            RefreshPathSnapshot();

            if (ShouldMoveDirectlyWithinGoalCell())
            {
                MoveDirectlyWithinGoalCell();
            }

            return;
        }

        RefreshPathSnapshot();
    }

    /// <summary>
    /// Returns true when recovery consumed the current fixed tick.
    /// </summary>
    private bool EvaluateMovementProgressAndRecover()
    {
        if (!movementExpectedLastTick)
        {
            progressReferencePosition = body.position;
            noProgressDuration = 0f;
            isStuck = false;
            return false;
        }

        float movedDistance = Vector2.Distance(
            body.position,
            progressReferencePosition);

        movementExpectedLastTick = false;

        if (movedDistance >= stuckMovementThreshold)
        {
            progressReferencePosition = body.position;
            noProgressDuration = 0f;
            isStuck = false;
            recoveryAttemptCount = 0;
            lastFailureReason = EnemyPathFailureReason.None;
            lastFailureDetails = string.Empty;
            return false;
        }

        noProgressDuration += Time.fixedDeltaTime;

        if (noProgressDuration < stuckTimeout)
        {
            return false;
        }

        BeginStuckRecovery();
        return true;
    }

    private void BeginStuckRecovery()
    {
        isStuck = true;
        recoveryAttemptCount++;
        totalRecoveryCount++;
        lastFailureReason = EnemyPathFailureReason.StuckDetected;
        lastFailureDetails =
            "No movement above " + stuckMovementThreshold +
            " for " + noProgressDuration + " seconds.";

        CancelPendingRequest();
        currentPath.Clear();
        pathIndex = 0;
        waitingAtWaypointForRepath = false;
        hasQueuedRepath = hasDesiredDestination;
        motor.Stop();

        if (recoveryAttemptCount > maximumRecoveryAttempts)
        {
            RegisterFailure(
                EnemyPathFailureReason.RecoveryAttemptsExhausted,
                "Stuck recovery exceeded " +
                maximumRecoveryAttempts + " consecutive attempts.");

            return;
        }

        if (!pathService.TryFindNearestWalkableCell(
                body.position,
                1,
                out Vector2Int recoveryCell))
        {
            RegisterFailure(
                EnemyPathFailureReason.RecoveryCellUnavailable,
                "No walkable recovery cell exists within one grid cell.");

            return;
        }

        Vector2 recoveryPosition =
            pathService.CellToWorld(recoveryCell);

        float recoveryDistance = Vector2.Distance(
            body.position,
            recoveryPosition);

        if (recoveryDistance > maximumRecoverySnapDistance)
        {
            RegisterFailure(
                EnemyPathFailureReason.RecoveryDistanceExceeded,
                "Nearest recovery cell is " + recoveryDistance +
                " world units away; maximum is " +
                maximumRecoverySnapDistance + ".");

            return;
        }

        if (recoveryDistance > waypointTolerance)
        {
            motor.SnapToRecoveryCell(recoveryPosition);
        }

        progressReferencePosition = body.position;
        noProgressDuration = 0f;
        isStuck = false;
        nextAllowedRepathAt =
            Time.time + minimumRepathInterval;

        navigationStatus = EnemyNavigationStatus.Recovering;
        RefreshPathSnapshot();
    }

    private void RegisterFailure(
        EnemyPathFailureReason reason,
        string details)
    {
        currentPath.Clear();
        pathIndex = 0;
        waitingAtWaypointForRepath = false;
        hasQueuedRepath = hasDesiredDestination;
        lastFailureReason = reason;
        lastFailureDetails = details ?? string.Empty;
        retryFailedRequestAt =
            Time.time + failedRequestRetryDelay;

        navigationStatus = EnemyNavigationStatus.Failed;
        motor.Stop();
        ResetProgressTracking();
        RefreshPathSnapshot();
    }

    private void CancelPendingRequest()
    {
        if (pathRequestPending && pathService != null)
        {
            pathService.CancelRequest(pendingRequestId);
        }

        pathRequestPending = false;
        pendingRequestId = 0;
    }

    private void ResetNavigationState()
    {
        currentPath.Clear();
        pathIndex = 0;
        hasDesiredDestination = false;
        desiredDestination = Vector2.zero;
        hasKnownTargetCell = false;
        knownTargetCell = default(Vector2Int);
        hasQueuedRepath = false;
        waitingAtWaypointForRepath = false;
        pathRequestPending = false;
        pendingRequestId = 0;
        nextAllowedRepathAt = 0f;
        retryFailedRequestAt = 0f;
        lastPathCost = 0;
        lastExpandedNodeCount = 0;
        lastFailureReason = EnemyPathFailureReason.None;
        lastFailureDetails = string.Empty;
        noProgressDuration = 0f;
        isStuck = false;
        recoveryAttemptCount = 0;
        totalRecoveryCount = 0;
        submittedRequestCount = 0;
        acceptedPathCount = 0;
        failedPathCount = 0;
        progressReferencePosition = body != null
            ? body.position
            : (Vector2)transform.position;

        movementExpectedLastTick = false;

        if (context != null)
        {
            context.ClearLastKnownTargetPosition();
            context.ClearNavigationDestination();
        }

        RefreshPathSnapshot();
    }

    private void ResetProgressTracking()
    {
        movementExpectedLastTick = false;
        noProgressDuration = 0f;
        isStuck = false;
        progressReferencePosition = body != null
            ? body.position
            : (Vector2)transform.position;
    }

    private void RefreshPathSnapshot()
    {
        currentPathCount = currentPath.Count;
        hasCurrentWaypoint = HasActivePath;
        currentWaypoint = hasCurrentWaypoint
            ? currentPath[pathIndex]
            : Vector2.zero;
    }

    private void CacheComponents()
    {
        if (body == null)
        {
            body = GetComponent<Rigidbody2D>();
        }

        if (pathfinder == null)
        {
            pathfinder = GetComponent<EnemyPathfinder>();
        }

        if (motor == null)
        {
            motor = GetComponent<EnemyMotor2D>();
        }

        if (context == null)
        {
            context = GetComponent<EnemyRuntimeContext>();
        }

        if (detection == null)
        {
            detection = GetComponent<EnemyDetection>();
        }
    }

    private void OnDisable()
    {
        CancelPendingRequest();
    }

    private void OnDrawGizmosSelected()
    {
        if (!showPathGizmos || currentPath.Count == 0)
        {
            return;
        }

        Gizmos.color = Color.cyan;
        Vector3 previous = transform.position;

        for (int i = pathIndex; i < currentPath.Count; i++)
        {
            Vector3 next = currentPath[i];
            Gizmos.DrawLine(previous, next);
            Gizmos.DrawSphere(next, 0.07f);
            previous = next;
        }
    }
}
