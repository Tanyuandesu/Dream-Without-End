# Dream Dungeon 阶段 7 完整代码安装包

适用 Unity：`6000.0.26f1`

本包把已经通过的 R6 工程升级到阶段 7 最终代码状态：

- `GameManager` 正式分派 `ProceduralCells` 与 `HybridPrefabRooms`。
- Hybrid 使用 R6 Runtime Layout。
- 房间实例化真实 Room Prefab。
- Connection 打开实例 Socket，未使用门保持关闭。
- 走廊地板与走廊墙程序化生成。
- 保留旧 `DungeonGenerator.Generate(int)` 与完整 ProceduralCells 路径。

本包不包含 `GameScene.unity`、Prefab、Catalog、Packages 或 ProjectSettings，避免覆盖使用者场景中的其他系统和 UI 布局。

安装和验收请从 `00_INSTALL_AND_VALIDATION_CN.md` 开始。

