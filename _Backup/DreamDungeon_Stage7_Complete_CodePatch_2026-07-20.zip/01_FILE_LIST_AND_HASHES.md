# 文件清单与 SHA-256

## 新增

| 文件 | SHA-256 |
|---|---|
| `Assets/Scripts/Dungeon/HybridRooms/DungeonGenerator.RuntimeHybrid.cs` | `c4d5834b7ab2d2069e0628f2e6a1c210d2efd21a87d633b141748f473e7079a5` |
| `Assets/Scripts/Dungeon/HybridRooms/DungeonGenerator.RuntimeHybrid.cs.meta` | `5a6fee8e5242b767c80d0b4591bc8cb6a7d67d42a4df7b004283318abb58fd78` |

## 替换

| 文件 | SHA-256 |
|---|---|
| `Assets/Scripts/GameManager.cs` | `c8944a1e837aaee86cf5606b9d6d55f1c048b983a59510609827571995e28097` |
| `Assets/Scripts/GameManager.cs.meta` | `fba6c957486c4bc3f73ca5f0816b855a9368d52f04c00df280295893464723a0` |
| `Assets/Scripts/Dungeon/HybridRooms/DungeonRenderer.cs` | `ebf8098021b98a982f449a074cf0e44ef719b957c065096299c14681e13c32c0` |
| `Assets/Scripts/Dungeon/HybridRooms/DungeonRenderer.cs.meta` | `6fa9b0cab3520a1faaa677e6bd04800f0a020e025e189257638852e6a102838c` |

稳定 GUID：

```text
GameManager.cs                    51d60c128a42688428e0b7f8993a95fb
DungeonGenerator.RuntimeHybrid.cs 063f70d45669fd1d0ce9cd1382969914
DungeonRenderer.cs                6d0980327b7349e4b89aeb18a8fa3d1d
```

不应新增、删除或替换其他 Unity 工程文件。

