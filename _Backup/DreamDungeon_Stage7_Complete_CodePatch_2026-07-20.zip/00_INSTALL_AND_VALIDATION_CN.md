# 阶段 7 完整代码安装、Inspector 与验收说明

## 1. 安装目的

安装后，GameManager 会根据 DungeonRenderer 的 Render Mode 选择正式运行路径：

```text
ProceduralCells
  → 原 DungeonGenerator.Generate(int)
  → 原逐格 Floors / Walls Renderer

HybridPrefabRooms
  → DungeonGenerator.RuntimeHybrid
  → 已通过 R6 的 Room Placement / Graph / Socket Corridor
  → Room Prefab + Connection 门 + 程序化走廊
```

Hybrid 请求失败时，日志和 Overlay 必须分别显示 Requested Mode 与 Effective Mode；不会静默伪装成 Hybrid 成功。

## 2. 安装前准备

1. 确认 Unity 版本为 `6000.0.26f1`。
2. 完全退出 Play Mode。
3. 关闭 Unity Editor，或至少等待所有编译和导入完成。
4. 复制整个工程作为备份，或建立 Git checkpoint。
5. 额外备份以下现有文件及 `.meta`：

```text
Assets/Scripts/GameManager.cs
Assets/Scripts/GameManager.cs.meta
Assets/Scripts/Dungeon/HybridRooms/DungeonRenderer.cs
Assets/Scripts/Dungeon/HybridRooms/DungeonRenderer.cs.meta
```

6. 不要从项目内历史文件 `Assets/Scripts/7_8_backup.zip` 恢复代码。

## 3. 复制文件

将本包中的 `Assets/` 拖到 Unity 项目根目录，与现有 `Assets/` 合并。

只应发生：

- 新增 RuntimeHybrid 的 `.cs` 与 `.meta`。
- 替换 GameManager 的 `.cs` 与同 GUID `.meta`。
- 替换 DungeonRenderer 的 `.cs` 与同 GUID `.meta`。

不要删除：

- `ProceduralCells` 枚举值。
- `DungeonGenerator.Generate(int)`。
- R4、R5、R6 脚本。
- Room Prefab、Catalog 或 Scene 中既有 Manager。

## 4. 第一次打开 Unity

1. 用 Unity `6000.0.26f1` 打开工程。
2. 等待右下角导入、刷新和脚本编译全部结束。
3. 打开 `Assets/Scenes/GameScene.unity`。
4. 打开 Console，点击 `Clear`。
5. 确认红色错误数为 0。

如果出现编译错误，停止安装，不要继续保存 Scene。选中第一条红错并保存完整堆栈，然后恢复安装前备份。

## 5. GameManager Inspector 正式设置

选择 Hierarchy 中的 `GameManager`。

### DungeonGenerator

```text
Corridor Width                         2
Use Random Seed                        开启（正式运行）
Fixed Seed                             12345
Socket Corridor Width                  2
Template First Room Catalog            RoomCatalog_Graybox
Template First Desired Room Count      7
```

固定复现测试时临时关闭 `Use Random Seed`；最终正式状态再开启。

### DungeonRenderer

```text
Render Mode                                      HybridPrefabRooms
Log Hybrid Fallback                              开启
R73 Inject Missing Socket For Controlled Failure 关闭
R74 Inject Invalid Corridor Cell For Failure     关闭
Cell Size                                        1
```

### GameManager

```text
Generate On Start  开启
Show Debug Overlay 开启
```

保存 Scene 与 Project。

## 6. Hybrid 固定 Seed 成功测试

1. 退出 Play Mode。
2. 临时关闭 `Use Random Seed`。
3. `Fixed Seed = 12345`。
4. 确认两个受控失败开关均关闭。
5. Console `Clear`。
6. Play。

Overlay 应显示：

```text
Floor: 1
Rooms: 7
Seed: 12345
Requested Mode: HybridPrefabRooms
Effective Mode: HybridPrefabRooms
Status: 直接成功
```

关键日志应包含：

```text
[GameManager/R7.1]
Requested=HybridPrefabRooms
Effective=HybridPrefabRooms
Placements=7
Connections=8
FloorCells=823

[DungeonRenderer/R7.4]
RoomInstances=7/7
Connections=8/8
TotalSockets=28
OpenedSockets=16
ClosedUnusedSockets=12
CorridorFloors=271/271
CorridorFloorColliders=0
CorridorWalls=224
CorridorWallColliders=224
SharedCorridorCells=Deduplicated
```

Hierarchy 应有：

```text
GeneratedDungeon_Floor_1
├── Rooms                 7 个实例
├── Corridors             271 个地板对象
└── CorridorWalls         224 个带 Collider 的墙对象
```

说明：GameManager/R7.1 成功日志末尾仍可能包含早期阶段文字“R7.1 仍由 ProceduralCells 过渡显示”。该尾句不是当前 Effective Mode；以同一日志的 Requested/Effective、Overlay 和 R7.4 Renderer 提交日志为准。

## 7. 物理成功测试

玩家至少完成：

1. 从 Start 房间进入另外两个房间。
2. 通过一个 90 度转弯走廊。
3. 通过一个汇合或共享走廊段。
4. 确认连接门可通过。
5. 确认一个未使用 DoorBlocker 无法穿越。
6. 确认走廊外墙无法穿越。

敌人寻路容易卡住是阶段 8 的已知待测事项，不修改敌人 AI 作为阶段 7 安装条件。

## 8. R、换层与随机 Seed

固定 Seed 下按一次 `R`：

- Floor 仍为 1。
- Seed 仍为 12345。
- 最终只存在一个 Floor 1 root 和一个 Player。
- 地图一致，玩家仍可移动。

进入黄色 Exit：

- Floor 变为 2。
- Seed 变为 12346。
- Floor 1 root 被销毁。
- 最终只存在一个 Floor 2 root 和一个 Player。

随后退出 Play，开启 `Use Random Seed`，再次 Play。随机 Seed 应变化，Hybrid 仍直接成功且没有 fallback。

## 9. R7.3 受控失败测试

1. 退出 Play。
2. 关闭随机 Seed，固定为 12345。
3. 开启 `R73 Inject Missing Socket For Controlled Failure`。
4. 保持 R7.4 失败开关关闭。
5. Play。

预期：

```text
[DungeonRenderer/R7.3] Connection 门状态提交被拒绝
RoomInstances=7/7
Connections=0/8
OpenedSockets=0
ClosedSockets=28
```

所有实例门保持关闭，不提交部分开门状态，Prefab Asset 不被修改。

恢复：退出 Play，关闭 R7.3 开关，Clear 后重新 Play，必须再次得到 8/8、16 个 OpenedSockets 的成功日志。

## 10. R7.4 受控失败测试

1. 退出 Play。
2. 开启 `R74 Inject Invalid Corridor Cell For Controlled Failure`。
3. 保持 R7.3 开关关闭。
4. Play。

预期：

```text
[DungeonRenderer/R7.4] 走廊渲染提交被拒绝
InFinalFloorCells=True
InRoomOccupiedCells=True
CorridorRender=Rejected
DoorActivation=Rejected
Connections=0/8
OpenedSockets=0
CorridorFloors=0/271
CorridorWalls=0
```

恢复：退出 Play，关闭 R7.4 开关，Clear 后重新 Play，必须再次得到完整 Hybrid 成功日志。

## 11. ProceduralCells 回归

1. 退出 Play。
2. Render Mode 改为 `ProceduralCells`。
3. 固定 Seed 12345。
4. Play。

应显示：

```text
Requested Mode: ProceduralCells
Effective Mode: ProceduralCells
Status: 直接成功
HasHybridRoomData=False
```

Hierarchy 使用 `Floors` 与 `Walls`，不应建立 Hybrid 的 Rooms/Corridors/CorridorWalls。

按 R 后仍为 Floor 1 / Seed 12345；进入 Exit 后为 Floor 2 / Seed 12346。旧 root 与旧玩家不能重复残留。

## 12. 最终恢复状态

所有测试结束后：

```text
Render Mode   HybridPrefabRooms
Use Random Seed 开启
R7.3 失败开关 关闭
R7.4 失败开关 关闭
Cell Size     1
Corridor Width 2
```

退出 Play，保存 Scene 与 Project。

## 13. 停止条件与恢复

出现以下任一情况，不要进入阶段 8：

- Console 新增红色编译或运行错误。
- Requested Hybrid 但 Effective Procedural，且没有明确回退原因。
- 固定 Seed 不能重现。
- 连接数不是 8/8，开门 Socket 不是 16。
- 走廊穿入房间、门口被墙堵住或未使用门打开。
- R 或 Exit 后留下两个 root、两个 Player、旧敌人或旧道具。
- ProceduralCells 与原行为不同。

恢复顺序：

1. 退出 Play，不保存失败测试状态。
2. 关闭两个注入开关，恢复 Corridor Width 2、Cell Size 1。
3. 重新运行固定 Seed 成功测试。
4. 若仍失败，恢复安装前脚本备份和 `.meta`，不要从历史聊天包混装。

