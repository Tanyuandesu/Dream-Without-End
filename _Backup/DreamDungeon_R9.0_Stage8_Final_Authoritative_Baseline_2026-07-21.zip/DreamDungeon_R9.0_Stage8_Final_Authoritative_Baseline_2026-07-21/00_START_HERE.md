# Dream Dungeon R9.0：阶段 8 最终权威基线

日期：2026-07-21  
Unity：6000.0.26f1  
状态：阶段 8 已封板，R9.0 冻结通过

## 本包是什么

这是用户在 R8.5 全部验收通过后、退出 Play Mode、保存 GameScene 与 Project、关闭 Unity 后提交的完整工程快照。

从 R9.1 起，本包取代以下内容，成为新的唯一工程事实源：

- 2026-07-15 的阶段 7–9 初始交接包；
- 阶段 7 的中间权威包；
- R8.1、R8.2、R8.3、R8.4、R8.4.1 的单独安装包。

旧包仍可用于追溯修改历史，但不得覆盖本包中的同名文件。

## 快照位置

`ProjectSnapshot/` 下直接包含：

- `Assets/`
- `Packages/`
- `ProjectSettings/`

需要恢复时，将这三个文件夹复制到一个 Unity 工程根目录。不要把本包的说明文档复制到 Assets。

## 当前冻结状态

- 默认 Render Mode：`HybridPrefabRooms`
- 固定 Seed：`12345`
- Use Random Seed：关闭
- Corridor Width：`2`
- Socket Corridor Width：`2`
- Graybox Catalog：`RoomCatalog_Graybox`
- R7.3、R7.4、R8.2、R8.3、R8.4 受控失败开关：全部关闭
- `GameManager.cs`：已包含 R8.4.1 Camera Target 审计修正
- ProceduralCells：保留为完整回退路径

## R9.1 起的护栏

1. 不直接修改 `RoomCatalog_Graybox` 或四个 R3 灰盒 Prefab 来试验非矩形内容。
2. 新样本使用独立目录与独立 Catalog。
3. 不重写 R4 矩形边界放置、R5 图连接或 R6 Socket 走廊。
4. 非矩形数据的权威仍是 Local Cell，不是 Transform 位置。
5. 每个阶段完成后继续验证 Hybrid 与 ProceduralCells 回退。

详细审计见 `01_R9.0_AUDIT_REPORT.md`，阶段 8 实机记录见 `02_STAGE8_ACCEPTANCE_RECORD.md`。
