# DreamDungeon Stage 7 Authoritative Handoff

这是 Dream Dungeon 混合房间系统在阶段 7 完成后的权威冻结包。

阶段 7 已完成：正式 Play Mode 可以请求 Hybrid Layout，实例化 Room Prefab，按 Connection 开门，并以程序化地板与墙连接房间；旧 ProceduralCells 路径仍完整可用。

下一项唯一工作是 `04_STAGE8_IMPLEMENTATION_PLAN.md` 中的 R8.0 零改动兼容测试。不要重新制作 R0–R7，也不要直接进入 SpawnPoint 实装。

## 阅读顺序

1. `00_START_HERE.md`
2. `01_CURRENT_STAGE7_BASELINE.md`
3. `02_AUTHORITATIVE_SOURCE_MAP.md`
4. `03_RUNTIME_DEPENDENCY_AND_DATA_CONTRACTS.md`
5. `04_STAGE8_IMPLEMENTATION_PLAN.md`
6. `07_KNOWN_ISSUES_AND_GUARDRAILS.md`
7. `09_STAGE7_IMPLEMENTATION_AND_AUDIT_REPORT.md`
8. 开始 R8.0

## 目录

| 内容 | 用途 |
|---|---|
| `SourceProjectSnapshot/` | 2026-07-20 当前实际工程的 Assets、Packages、ProjectSettings |
| `InstallPackage/` | 从 R6 安装完整阶段 7 代码的独立补丁 |
| `ReferenceEvidence/R6/` | R6 冻结证据 |
| `ReferenceEvidence/Stage7/` | 阶段 7 Inspector、成功、失败、恢复和回归证据 |
| `08_NEW_THREAD_BOOTSTRAP_PROMPT.txt` | 新对话继续 R8.0 的完整开场提示 |
| `10_STAGE7_EVIDENCE_INDEX.md` | 每张证据的证明范围与限制 |
| `MANIFEST_SHA256.txt` | 包内文件校验值 |
