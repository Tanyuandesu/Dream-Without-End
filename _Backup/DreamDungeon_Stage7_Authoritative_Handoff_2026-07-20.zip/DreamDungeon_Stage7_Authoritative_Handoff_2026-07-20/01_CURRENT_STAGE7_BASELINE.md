# 当前 Stage 7 冻结基线

## 阶段状态

| 修订 | 结果 |
|---|---|
| R7.1 运行时模式分派 | 通过 |
| R7.2 Room Prefab 实例化 | 通过 |
| R7.3 Connection 门状态 | 通过 |
| R7.4 程序化走廊渲染 | 通过 |
| R7.5 完整 Play Mode 生命周期 | 通过 |
| R7.6 冻结审计 | 通过 |

## 固定 Seed 12345 Hybrid 基线

| 项目 | 已验证值 |
|---|---:|
| Floor | 1 |
| Room Instances | 7 / 7 |
| Connections | 8 / 8 |
| Total Instance Sockets | 28 |
| Opened Connection Sockets | 16 |
| Closed Unused Sockets | 12 |
| Corridor Width | 2 |
| Corridor Floors | 271 / 271 |
| Corridor Floor Colliders | 0 |
| Corridor Walls | 224 |
| Corridor Wall Colliders | 224 |
| Occupied Room Cells | 552 |
| Shared Corridor Cells | 13，渲染去重 |
| Final Floor Cells | 823 |
| Reachable From Start | 823 / 823 |

运行时 Hierarchy：

```text
GameManager
└── GeneratedDungeon_Floor_N
    ├── Rooms
    ├── Corridors
    └── CorridorWalls
```

## 随机 Seed 验证样本

一个已保存的随机样本验证：

```text
RoomInstances=7/7
Connections=8/8
TotalSockets=28
OpenedSockets=16
ClosedUnusedSockets=12
CorridorFloors=368/368
CorridorFloorColliders=0
CorridorWalls=335
CorridorWallColliders=335
OccupiedRoomCells=744
```

说明随机布局变化时，房间、连接、门、走廊和墙统计仍保持内部一致。

## 已通过的生命周期

- Hybrid 首层生成。
- Hybrid 固定 Seed 重现。
- Hybrid 随机 Seed 变化。
- Hybrid 按 R 清理旧 root 并重建同层。
- Hybrid 进入 Exit 后建立下一层。
- 玩家对象跨 R／换层复用，不重复创建。
- ProceduralCells 直接模式首层、R、Exit 全流程。
- 固定 Seed 下 Floor 1 为 12345，Floor 2 为 12346。

## 已通过的物理契约

- 玩家从 Prefab 房间进入走廊，再进入其他房间。
- 玩家通过转弯和共享走廊段。
- 已连接门口没有残留 DoorBlocker。
- 未使用门保持封闭。
- Prefab 外墙与 Corridor Wall 阻挡玩家。
- 程序墙不进入房间 Occupied Cells。
- 走廊 Floor 不添加 Collider，墙添加一格 BoxCollider2D。

## 已通过的受控失败

### R7.3 Missing Socket

```text
RoomInstances=7/7
Connections=0/8
OpenedSockets=0
ClosedSockets=28
DoorActivation=Rejected
```

恢复关闭注入后再次 8/8 成功。

### R7.4 Invalid Corridor Cell

```text
InFinalFloorCells=True
InRoomOccupiedCells=True
Connections=0/8
OpenedSockets=0
CorridorFloors=0/271
CorridorWalls=0
CorridorRender=Rejected
DoorActivation=Rejected
```

恢复关闭注入后再次完整成功。

## 模式语义

| Requested | Effective | 含义 |
|---|---|---|
| ProceduralCells | ProceduralCells | 主动运行旧路径 |
| HybridPrefabRooms | HybridPrefabRooms | Hybrid Layout 生成成功 |
| HybridPrefabRooms | ProceduralCells | Hybrid 生成／提交前校验失败，明确回退 |

R7.3/R7.4 Renderer 事务被拒绝时，Layout 的 Effective Generation Mode 仍可能是 Hybrid；日志会另外显示 `DoorActivation=Rejected` 或 `CorridorRender=Rejected`。不要把生成模式与渲染提交结果混为一谈。

## 冻结边界

以下源码继续冻结：

- `DungeonGenerator.Generate(int)`。
- R4 Template First 放置。
- R5 Room Graph。
- R6 Socket 分配与 A* Corridor。
- `DungeonLayout.CreateHybrid` 数据含义。
- DreamRoomTemplate／Placement／Connection／DoorSocket 契约。
- 四个灰盒 Prefab 与 RoomCatalog_Graybox。

阶段 8 不应为了形式重写这些文件。

