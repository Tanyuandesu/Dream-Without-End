# 已知事项与护栏

## R8.0 首要观察项：敌人追踪

玩家已经验证 Hybrid 房间、连接门、转弯走廊和墙体可正常通行，但同时观察到敌人容易在房间／走廊转换处卡住。

这不阻断阶段 7 冻结，因为阶段 7 的职责是建立正确的 Layout、Prefab、门与走廊；Enemy AI 本来就在阶段 8 做专项兼容验收。R8.0 应先记录可复现条件：

- 敌人与玩家分别位于哪个房间。
- 卡在门口、直走廊、转弯还是共享走廊。
- 敌人是否有路径但移动失败，还是路径根本没有刷新。
- 固定 Seed、Floor、起止格和 Console 日志。
- ProceduralCells 下同一 AI 是否也会出现。

不要在取得上述证据前，临时加瞬移、穿墙、加大门宽或重写寻路。

## 现有两条黄色 Missing Script 警告

用户的正常 Play 截图中持续出现两条：

```text
The referenced script (Unknown) on this Behaviour is missing!
```

它们在阶段 7 前后均未表现为红色编译／运行错误，也没有阻止地图、玩家、R 或换层。静态审计结果：

- 当前 Assets 中没有 `m_Script: {fileID: 0}`。
- GameScene 自有脚本 GUID 都可解析。
- GameScene 的非 Assets 脚本 GUID 集合与 R6 一致，对应已安装 Package。
- Assets 没有缺失 `.meta`、孤立 `.meta` 或重复 GUID。

因此 R7.6 不猜测性删除组件，也不把消除该旧警告混入地图修订。R8.0 可在运行时展开警告并定位对象；若警告数量增加、变成红错或影响功能，则立即停止并单独诊断。

## 一次非稳定 Unity Editor Assertion

用户在组合受控失败操作的截图中曾看到一条 Unity GUI 内部 Assertion。它没有在干净恢复后的正常运行中复现，也没有进入最终保存状态。

不要把它记成已修复的游戏代码问题；如果 R8.0 正常操作可以稳定复现，保存完整堆栈、Unity 操作顺序和发生频率，再单独处理。

## R7.1 成功日志的旧尾句

当前 `GameManager` 的 R7.1 成功日志末尾仍可能显示：

```text
R7.1 仍由 ProceduralCells 过渡显示。
```

这是早期小修订遗留的描述文字，不代表实际渲染模式。判断方式按优先级为：

1. Overlay 的 Requested Mode 与 Effective Mode。
2. 同一 GameManager 日志中的 Requested／Effective／HasHybridRoomData。
3. `[DungeonRenderer/R7.4]` 的实际提交日志。
4. Hierarchy 是否存在 Rooms／Corridors／CorridorWalls。

这条文字属于已记录的可读性债务，不在 R7.6 顺便修改，避免让冻结源码与已测试哈希分叉。

## 当前性能边界

阶段 7 为了可检查性按格创建走廊地板和走廊墙对象。固定 Seed 12345 会创建 271 个走廊 Floor 对象和 224 个墙对象；这是当前已接受的正确性实现，不是最终性能规格。

只有在功能循环稳定并取得 Profiler 数据后，才评估 Tilemap、合并 Collider、对象池或 Mesh。不要在 R8.0 一边诊断 AI 一边改渲染结构。

## Scene 中保留的非阶段 7 差异

当前实际 GameScene 的 `CircularHealthPanel` Anchored Position 与 2026-07-15 R6 快照不同。该 UI 差异不是阶段 7 代码改动，完整工程快照按用户实际保存状态保留；独立代码补丁不包含 GameScene，因此不会覆盖该位置。

如果后续要判断 UI 是否正确，应以 R8.0 实际画面为准，不要擅自回写 R6 坐标。

## 历史备份文件已移除

`Assets/Scripts/7_8_backup.zip` 及其 `.meta` 不在当前工程中。旧交接已经明确该文件是历史脚本包、不能覆盖权威源码，因此本次不恢复它，也不把它列为运行依赖。

## R6 Preview 仍可保留

`DungeonSocketCorridorR6Preview` 仍挂在 GameManager 上。它没有自动 Play 生命周期，只用于手动 Context Menu／Scene Gizmo 诊断，不会替代正式 Renderer。

若 Gizmo 影响观察，可以临时关闭 Gizmo 显示；不要为了清理 Inspector 删除 R6 脚本或重做组件。

## 灰盒 SpawnPoints 为空

四个灰盒 Prefab 当前 SpawnPoints 为空，这是阶段 8 计划已经覆盖的正常状态。现有 Start、Exit、Enemy、Item 继续使用兼容回退规则。

R8.0 先验证旧规则；只有实际问题才进入 R8.1。不能把“计划将来支持 SpawnPoint”误认为当前 Prefab 缺数据或阶段 7 失败。

## 引用与坐标护栏

- GameManager 的序列化 DungeonRenderer 引用即使显示为空，也会由同 GameObject 上的 `GetComponent` 缓存；先确认组件存在，不要重复添加 Renderer。
- GameManager Transform 不在世界原点，不能把 dungeon root 的 Transform 当成格子原点。
- Cell Size 固定为 1，Prefab 根 Scale 固定为 `(1,1,1)`。
- Placement 姿态继续使用 `DreamRoomPlacement.ApplyPose()`。
- 只修改实例上的 Socket／DoorBlocker，禁止修改 Prefab Asset 的门状态。
- Corridor Width 与 Socket Corridor Width 继续为 2。

## 正式状态与停止条件

进入 R8.0 前必须保持：

```text
Render Mode                 HybridPrefabRooms
Log Hybrid Fallback         true
R7.3 Controlled Failure     false
R7.4 Controlled Failure     false
Use Random Seed             true
Cell Size                   1
Corridor Width              2
Socket Corridor Width       2
```

出现以下任一项，停止进入下一小修订：

- 新增红色编译／运行错误。
- Requested 与 Effective 不一致，却没有明确回退原因。
- 正常模式触发 DoorActivation／CorridorRender Rejected。
- R 或换层留下重复 root、Player、Enemy 或 Item。
- 玩家穿墙、已连接门被堵、未使用门打开。
- 敌人问题同时伴随 `FloorCells` 错误或穿墙，而不只是移动卡住。
- 当前文件哈希与 `MANIFEST_SHA256.txt` 不一致且无法解释。

