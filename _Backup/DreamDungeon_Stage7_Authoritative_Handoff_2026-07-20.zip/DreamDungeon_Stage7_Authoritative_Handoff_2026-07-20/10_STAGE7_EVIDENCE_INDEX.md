# 阶段 7 证据索引

## 使用原则

本目录保存用户在 Unity `6000.0.26f1` 中实际运行与最终恢复的截图。证据用于支持验收结论，不取代 `SourceProjectSnapshot/` 的源码权威性。

截图可能同时包含阶段外既有黄警告；每张证据只证明下表列出的事实，不把未显示的内容外推成已验证。

## R6 冻结证据

| 文件 | 证明范围 |
|---|---|
| `ReferenceEvidence/R6/R6_Console_Validation_Passed.png` | R6 Door Socket 与 A* 走廊建立成功、Rooms／Connections／FloorCells 统计 |
| `ReferenceEvidence/R6/R6_Scene_Routed_Corridors.png` | R6 Scene Gizmo 中房间、Socket 和已路由走廊的空间关系 |

## Stage 7 证据

| # | 文件 | 证明范围 |
|---:|---|---|
| 01 | `ReferenceEvidence/Stage7/01_Final_Inspector_Hybrid.png` | 最终 Renderer 为 HybridPrefabRooms；Log Hybrid Fallback 开；R7.3/R7.4 注入关；Cell Size 1；R6 Preview 保留 |
| 02 | `ReferenceEvidence/Stage7/02_R71_DirectHybrid_Success.png` | Requested Hybrid、Effective Hybrid、Status 直接成功；真实 Room Prefab 画面 |
| 03 | `ReferenceEvidence/Stage7/03_R71_ExplicitProceduralFallback.png` | Requested Hybrid、Effective ProceduralCells、Status 已明确回退；没有静默伪装 |
| 04 | `ReferenceEvidence/Stage7/04_R73_ControlledMissingSocketFailure.png` | Missing Socket 受控失败；Connection 0/7 或 0/8 提交前即拒绝；OpenedSockets 0；全部实例门保持关闭 |
| 05 | `ReferenceEvidence/Stage7/05_R73_RecoverySuccess.png` | 关闭 R7.3 注入后 Hybrid 恢复直接成功 |
| 06 | `ReferenceEvidence/Stage7/06_R74_RandomSeed_HybridSuccess.png` | 随机 Seed 下 7/7 房间、8/8 Connection、16 开门 Socket、程序化走廊提交；玩家可处于 Hybrid 地图 |
| 07 | `ReferenceEvidence/Stage7/07_R74_FixedSeed_RepeatedSuccess.png` | Fixed Seed 12345 重复生成结果一致；R7.4 成功日志重复出现 |
| 08 | `ReferenceEvidence/Stage7/08_R74_ControlledCorridorFailure.png` | Invalid Corridor Cell 被预检拒绝；门与走廊都不做半提交 |
| 09 | `ReferenceEvidence/Stage7/09_ProceduralCells_DirectMode.png` | Requested／Effective 均为 ProceduralCells；旧逐格地图仍可直接运行 |

## 用户口头验收、未单独保存进包的项目

以下结果由用户在同一测试链中明确确认，但现有证据目录没有每一项的独立完整截图：

- Hybrid 玩家通行符合预期，没有观察到穿墙或门失效。
- Hybrid 按 R 刷新通过。
- Hybrid 进入 Exit 换层通过。
- ProceduralCells 按 R 与 Exit 换层通过。
- R7.4 失败恢复后再次成功。
- 敌人会追踪但容易卡路，转入 R8.0 专项观察。

这些项目已足以支持阶段 7 生命周期验收，但 R8.0 仍需按系统重新收集更有针对性的 Enemy／Item／Camera／UI 证据。

## 证据不能证明的事项

- 不证明正式美术已经完成。
- 不证明非矩形房间已经实现。
- 不证明 Enemy AI 在所有路径上可靠。
- 不证明最终性能或发布平台帧率。
- 不证明两个既有黄色 Unknown Missing Script 警告的来源已经定位。

