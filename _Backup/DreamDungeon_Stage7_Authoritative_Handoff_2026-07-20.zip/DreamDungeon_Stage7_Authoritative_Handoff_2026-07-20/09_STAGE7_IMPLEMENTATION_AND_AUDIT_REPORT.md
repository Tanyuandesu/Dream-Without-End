# 阶段 7 实装与 R7.6 冻结审计报告

## 结论

R7.1–R7.6 已完成并通过冻结。用户提交的最终 `Assets`、`Packages`、`ProjectSettings` 与实际测试过的阶段 7 代码逐字节一致；R0–R6 核心算法、旧 `DungeonGenerator.Generate(int)`、灰盒 Catalog／Prefab、Packages 和 ProjectSettings 没有被阶段 7 改写。

当前权威工程可以直接作为 R8.0 起点。R7.6 不再需要额外 Play Mode 重测。

## 阶段 7 实际完成内容

### R7.1：正式运行模式分派

- GameManager 从 Renderer 读取 Requested Mode。
- `ProceduralCells` 继续调用旧 `Generate(int)`。
- `HybridPrefabRooms` 调用 R4–R6 Runtime Hybrid Layout。
- Overlay 与日志分开显示 Requested／Effective。
- Hybrid 失败有明确原因并可回退，不静默伪装成功。
- 新 Layout 在删除旧层前完成准备，避免失败时先丢失当前层。

### R7.2：Room Prefab 实例化

- 按 `RoomPlacements` 实例化 7 个真实灰盒 Prefab。
- 使用 Placement 的模板、中心格和 Quarter Turns。
- 只操作实例，不修改 Prefab Asset。
- 实例化失败时拒绝 Hybrid 渲染提交。

### R7.3：Connection 门状态

- 每条 Connection 按房间索引与 Socket Id 定位两个实例 Socket。
- 固定基线打开 16 个唯一已用 Socket，12 个未使用 Socket 保持封闭。
- Missing Socket 受控失败验证了全关门、0/8 提交、无预测替代 Socket。
- 关闭注入后恢复 8/8。

### R7.4：程序化走廊

- 只消费 `layout.CorridorCells`。
- Shared Corridor Cell 去重。
- 走廊 Floor 无 Collider；边界墙有 BoxCollider2D。
- 墙候选排除最终 FloorCells 与房间 Occupied Cells。
- 房间、门与走廊统一事务提交。
- Invalid Corridor Cell 受控失败验证了 0 门、0 走廊、0 墙的拒绝结果。

### R7.5：完整生命周期

- Hybrid 玩家通行通过。
- 固定／随机 Seed 通过。
- R 同层重建通过。
- Exit 下一层通过。
- Player 不重复创建。
- ProceduralCells 直接模式首层、R、Exit 全流程通过。

### R7.6：冻结

- 最终 Inspector 恢复为 Hybrid。
- 两个受控失败开关关闭。
- Use Random Seed 开启。
- Scene、脚本、`.meta`、Catalog、Prefab、Packages、ProjectSettings 完整封装。
- 生成权威工程快照、独立代码补丁、证据索引和 SHA-256 Manifest。

## 收到的实际工程输入

| 用户提交文件 | 大小 bytes | SHA-256 | 结果 |
|---|---:|---|---|
| `Assets(1).zip` | 12,282,068 | `4abd287a785076f6e0c6d4c911b896b40fbe18f4bf92265761746d46bba99eee` | `unzip -t` 通过 |
| `Packages(1).zip` | 2,118 | `f9765b87a43bdbcdb96836814cbf1eba5ce3d5f354adddc0d8ba8c6391c96189` | `unzip -t` 通过 |
| `ProjectSettings(1).zip` | 21,620 | `893ac691ad6b175af9258a101e9f1d0855d06fd2f159114da745e22890b6ec2a` | `unzip -t` 通过 |

输入 ZIP 没有绝对路径、父目录逃逸或其他不安全路径。权威包中的三份 ZIP 已重新规范为包含顶层 `Assets/`、`Packages/`、`ProjectSettings/` 的统一结构；重新压缩会改变 ZIP 文件哈希，但解压后的内容未改。

## 静态工程完整性

| 检查 | 结果 |
|---|---|
| Unity 版本 | `6000.0.26f1 (ccb7c73d2c02)` |
| Assets 实际文件 | 635 |
| C# 脚本 | 104 |
| `.meta` 缺失 | 0 |
| 孤立 `.meta` | 0 |
| 重复 GUID | 0 |
| `m_Script: {fileID: 0}` | 0 |
| Build Scenes | TitleScene、GameScene、EndingScene，全部启用 |
| Packages 内容差异 | 相对 R6 为 0 |
| ProjectSettings 内容差异 | 相对 R6 为 0 |
| GameScene 非 Assets 脚本 GUID 集合 | 与 R6 一致 |

Package 关键版本：URP `17.0.3`、Input System `1.11.2`、AI Navigation `2.0.4`、UGUI `2.0.0`、Visual Scripting `1.9.4`。

## 阶段 7 代码范围

相对 2026-07-15 R6 权威快照，运行代码只包含：

新增：

```text
Assets/Scripts/Dungeon/HybridRooms/DungeonGenerator.RuntimeHybrid.cs
Assets/Scripts/Dungeon/HybridRooms/DungeonGenerator.RuntimeHybrid.cs.meta
```

替换：

```text
Assets/Scripts/GameManager.cs
Assets/Scripts/Dungeon/HybridRooms/DungeonRenderer.cs
```

替换脚本的 `.meta` GUID 保持稳定。完整工程的 GameScene 还保存了正式 `renderMode: HybridPrefabRooms`、两个关闭的失败开关，以及用户实际 UI 布局；独立代码补丁不包含 Scene，避免覆盖无关 UI。

## 核心文件一致性

| 文件 | 最终 SHA-256 | 与测试累计源码 |
|---|---|---|
| `GameManager.cs` | `c8944a1e837aaee86cf5606b9d6d55f1c048b983a59510609827571995e28097` | 相同 |
| `DungeonGenerator.RuntimeHybrid.cs` | `c4d5834b7ab2d2069e0628f2e6a1c210d2efd21a87d633b141748f473e7079a5` | 相同 |
| `DungeonRenderer.cs` | `ebf8098021b98a982f449a074cf0e44ef719b957c065096299c14681e13c32c0` | 相同 |
| `GameScene.unity` | `9d9a32762b8644699fc929d2e934de99b76a2de3a08e344a75210fb7c53545c5` | 最终保存快照 |

R0–R6 的九个核心脚本哈希逐字节等于 2026-07-15 基线；完整列表见 `02_AUTHORITATIVE_SOURCE_MAP.md`。

## GameScene 最终序列化状态

```text
Render Mode                     HybridPrefabRooms
Log Hybrid Fallback             true
R7.3 Controlled Failure         false
R7.4 Controlled Failure         false
Cell Size                       1
Use Random Seed                 true
Fixed Seed                      12345
Corridor Width                  2
Socket Corridor Width           2
Generate On Start               true
Show Debug Overlay              true
Room Catalog                    Graybox_R3
```

用户提交的最终 Inspector 截图与上述 Renderer 字段一致。

## 运行证据覆盖

用户在目标 Unity Editor 中提供并完成：

- R7.1 Hybrid 直接成功与明确 Procedural fallback。
- R7.3 Missing Socket 失败与恢复。
- R7.4 随机成功、固定 Seed 重复成功、Invalid Corridor Cell 失败与恢复。
- Hybrid 玩家从房间到走廊的通行。
- R 与 Exit 换层。
- ProceduralCells 直接模式回归。
- 最终 Inspector 恢复。

证据文件与每张截图能证明的范围见 `10_STAGE7_EVIDENCE_INDEX.md`。截图只用于证明当时运行状态；源码真相仍是 `SourceProjectSnapshot/`。

## 已解释的非阶段 7 差异

### CircularHealthPanel

GameScene 中该 UI 的 Anchored Position 相对 R6 有变化。它不是阶段 7 脚本修改，完整实际快照予以保留，代码补丁不覆盖 Scene。

### 历史 `7_8_backup.zip`

当前快照不再包含该文件及 `.meta`。旧交接已把它标记为不可覆盖权威源码的历史包，因此不恢复。

### 两条黄色 Unknown Missing Script

运行截图可见两条旧黄警告，但静态快照未发现 fileID 0、缺失自有脚本 GUID、缺失／孤立 meta 或重复 GUID。R7.6 不越权猜测性清理；详细处理边界见 `07_KNOWN_ISSUES_AND_GUARDRAILS.md`。

## 审计限制

本容器没有启动 Unity Editor，因此没有在本地重新进行资源导入、C# 编译或 Play Mode。运行结论来自用户在目标 Unity `6000.0.26f1` 中提供的实际截图和逐步确认；静态审计证明最终源码与那些已测试交付逐字节一致。

这不是把“无法本地运行”伪装成测试通过。R7.6 的职责是确认：用户实际通过的工程已正确保存、没有混入旧源码、最终开关已恢复，并能无歧义交给下一阶段。以上条件均满足。

## 冻结判定

R7.6：**通过**。

下一项唯一工作是 R8.0 零修改兼容测试。阶段 7 不再继续追加小数点修订；如果 R8.0 暴露问题，应按其所属系统建立 R8.x，而不是回头改名为 R7.7。

