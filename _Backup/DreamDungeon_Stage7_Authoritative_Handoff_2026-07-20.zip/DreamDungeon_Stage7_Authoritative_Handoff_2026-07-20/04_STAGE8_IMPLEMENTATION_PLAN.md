# 阶段 8：接回玩家、出口、敌人和道具

## 阶段目标

确认旧游戏流程在 Hybrid Layout 上完整工作，然后才逐步启用 RoomTemplate 中已经预留的 SpawnPoint 数据。阶段 8 不改变房间放置和走廊算法。

## 先做零改动兼容测试

阶段 7 成功后，现有系统理论上已经可以工作：

- Player 使用 `StartCell`。
- Exit 使用 `ExitCell`。
- EnemyPathfinder 使用最终 `FloorCells`。
- Enemy/Item 使用兼容旧接口的 `Rooms` 与 `FloorCells`。
- Camera 只跟随玩家。

因此 R8.0 必须先运行完整 Play Mode，不要立刻改 Manager。只有可复现问题才成为修改依据。

R8.0 验收：

- 玩家生成在可行走格。
- 出口生成在可行走格。
- 敌人能跨房间、跨转弯走廊追踪玩家。
- 道具只生成在 `FloorCells`。
- 相机跟随正常。
- 触碰出口进入下一层。
- 按 R 重生成本层。
- 玩家生命状态与道具进度按现有规则保留。
- 背景进度系统继续收到楼层／道具状态。

若全部通过，说明阶段 7 已经恢复基本游戏，不需要为了形式改写全部 Manager。

## R8.1：统一安全出生格解析

### 当前风险

`EnemySpawner` 和 `ItemSpawner` 优先使用 `Rooms` 矩形中心。当前四个灰盒是完整矩形，所以合法；阶段 9 出现内部障碍或非矩形后，矩形中心可能不可走。

### 目标

建立一个纯数据的 Spawn Cell Resolver，统一保证候选格：

- 属于 `layout.FloorCells`。
- 不等于必要时应排除的 Start/Exit。
- 不与已占用出生格重复。
- 可按 RoomPlacement、SpawnPoint Kind 和权重选择。
- 没有专用点时有确定性回退。

推荐新增独立脚本，而不是在多个 Manager 中复制相同搜索。

## R8.2：Player 与 Exit SpawnPoint

### 数据来源

`DreamRoomSpawnPointKind.Player` 和 `Exit` 已经存在；`DreamRoomPlacement.GetSpawnPointGlobalCell()` 已经处理旋转。

### 选择规则

1. R5 仍负责选择 Start Room 和图距离最远的 Exit Room。
2. 在被选中的 Start Room 中查找 Player SpawnPoint。
3. 在 Exit Room 中查找 Exit SpawnPoint。
4. 多个候选按 `RandomWeight` 和 Layout Seed 确定性选择。
5. 没有候选时回退到当前代表性 Walkable Cell。
6. 最终仍写入 `DungeonLayout.StartCell/ExitCell`。

把选择结果写回 Layout，而不是让 GameManager 临时偏移，才能保证敌人寻路、道具排除距离和 Debug 信息共享同一个权威格。

灰盒 SpawnPoints 当前为空，所以“无标记回退”必须始终可用。

## R8.3：Enemy 与 Item SpawnPoint

Enemy：

- 优先使用 `DreamRoomSpawnPointKind.Enemy`。
- 排除 Start Room，按当前设置决定是否排除 Exit Room。
- 没有专用点时，从房间真实 Walkable Cells 中选离中心最近的合法格。
- 不再盲信矩形中心。

Item：

- 优先使用 `DreamRoomSpawnPointKind.Item`。
- 保留离 Start/Exit 的最小距离。
- 保留同 Seed、同楼层、同道具进度的确定性。
- 无专用点时回退到真实 Walkable Cells。

不要在阶段 8 把 ItemCatalog、SpawnPolicy 或道具收集进度重写掉。

## R8.4：跨楼层和失败恢复

必须验证：

1. Floor 1 正常生成。
2. 收集道具后进入 Floor 2。
3. `CollectedItemCount`、`ProgressionScore`、`LastCollectedFloor` 保持。
4. 玩家对象不重复创建。
5. 旧层敌人和道具引用被清理。
6. 旧 GeneratedDungeon root 被销毁。
7. 新层相机重新绑定玩家。
8. Hybrid 生成失败时，不丢失玩家对象和进度。

当前 `GameManager` 的事务式生成调整应在阶段 7 完成；阶段 8 要用实际流程验证它。

## R8.5：物理与寻路验收

至少测试：

- 玩家不能穿过 Prefab 墙、未使用 DoorBlocker、Corridor Wall。
- 玩家能通过所有已连接门口；宽度 2 对现有玩家 Collider 足够。
- 敌人不会把视觉墙当作可走格。
- 敌人从房间进入走廊、再进入另一个房间。
- 敌人路径不穿越第三个房间的墙。
- Item/Exit trigger 不被墙遮住。
- 玩家死亡、复活和 UI 不因地图模式改变。

## 阶段 8 完成标准

- Procedural 与 Hybrid 两种模式的完整游戏循环都通过。
- Start/Exit/Enemy/Item 的最终生成格都属于 `FloorCells`。
- 有 SpawnPoint 时优先使用，无 SpawnPoint 时可靠回退。
- 同 Seed 的候选选择可重现。
- R、下一层、进度保留、背景、相机、UI 全部正常。
- 不需要修改 R4/R5/R6 算法才能通过。

## 阶段 8 禁止事项

- 不让 SpawnPoint Transform 成为权威；权威是 `LocalCell`。
- 不在多个 Manager 中各写一套“最近可行走格”。
- 不删除旧 `Rooms`/`FloorCells` 兼容字段。
- 不把阶段 9 的非矩形占格和正式美术塞入阶段 8。

