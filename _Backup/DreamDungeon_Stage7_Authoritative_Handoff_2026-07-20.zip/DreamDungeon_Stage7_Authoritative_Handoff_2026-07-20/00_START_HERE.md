# 从这里开始

## 权威结论

阶段 7 已由用户在 Unity `6000.0.26f1` 中完成并通过验收。后续对话不得把阶段 7 当成待实现功能，也不得用历史聊天脚本覆盖本包快照。

阶段 7 当前提供：

- 正式运行时生成模式分派。
- Requested Mode 与 Effective Mode 明确区分。
- Hybrid 成功时使用真实 R6 Layout。
- 7 个灰盒 Room Prefab 实例。
- 8 条 Connection、16 个已打开实例 Socket。
- 12 个未使用 Socket 保持 DoorBlocker 关闭状态。
- 仅从 `layout.CorridorCells` 生成走廊地板。
- 走廊墙避开最终 FloorCells 与房间 Occupied Cells。
- 门与走廊事务式提交，失败不留下半开门或半条走廊。
- ProceduralCells、R、Exit 换层与随机 Seed 均保留。

## 唯一源码基线

`SourceProjectSnapshot/` 中三份 ZIP 是阶段 8 的源码真相：

```text
Assets.zip
Packages.zip
ProjectSettings.zip
```

它们来自用户完成 R7.6 恢复、保存并关闭 Unity 后提交的实际项目。

恢复方式：

1. 建立空项目目录。
2. 把三份 ZIP 解压到同一项目根目录。
3. 确认得到 `Assets/`、`Packages/`、`ProjectSettings/`。
4. 用 Unity `6000.0.26f1` 打开。
5. 等待导入和编译完成。
6. 不要传递或覆盖 `Library/`、`Temp/`、`Logs/`。

## 当前 GameScene 正式状态

```text
Render Mode                     HybridPrefabRooms
Log Hybrid Fallback             true
R7.3 Controlled Failure         false
R7.4 Controlled Failure         false
Cell Size                       1
Use Random Seed                 true
Fixed Seed                      12345
Corridor Width                  2
Socket Corridor Width           2
Generate On Start               true
Show Debug Overlay              true
Room Catalog                    Graybox_R3
```

## 下一项唯一工作

开始 R8.0：不修改脚本，运行完整 Hybrid Play Mode，专门检查 Player、Exit、Enemy、Item、Camera、Background、Health/UI 和进度兼容性。

用户已经观察到敌人容易在房间／走廊转换处卡住。R8.0 应把它变成可复现的路径与状态证据；不要在测试前先猜测性修改 Enemy AI。

R8.0 结束后，只有实际暴露的问题才成为 R8.1 以后修改的依据。

## 禁止事项

- 不重新设计 R0–R7。
- 不删除 ProceduralCells。
- 不修改 R4/R5/R6 算法来迎合 Manager。
- 不把 Renderer 变成生成器。
- 不静默回退。
- 不提前制作非矩形房间或替换正式美术。
- 不在 R8.0 顺便优化对象数量、Tilemap、Mesh 或 DOTS。

