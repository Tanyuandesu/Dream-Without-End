# 阶段 7 后的运行依赖与数据契约

## 正式调用链

```text
GameManager.GenerateFloor
  → 读取 DungeonRenderer.RenderMode 作为 Requested Mode
  → TryPrepareLayout
      ProceduralCells
        → 原 DungeonGenerator.Generate(floor)
      HybridPrefabRooms
        → TryGenerateHybridRuntimeLayout
        → R4 Template First
        → R5 Room Graph
        → R6 Socket Corridor
        → Hybrid 提交前校验
  → 只有 Layout 准备成功后才 RemoveCurrentFloor
  → 建立 GeneratedDungeon_Floor_N
  → DungeonRenderer.Render
      Procedural → Floors + Walls
      Hybrid     → Rooms + Corridors + CorridorWalls
  → PlayerManager.PlacePlayer
  → ExitSpawner.Spawn
  → ItemManager.SetupFloor
  → EnemyManager.SetupFloor
  → CameraManager.SetTarget
```

## 事务边界

GameManager 先准备并验证新 Layout，再删除旧层。Hybrid 生成失败时：

- Requested 保留 Hybrid。
- Effective 明确显示 ProceduralCells 或 Unchanged。
- 失败原因包含 R6 report／校验错误。
- 只有 fallback 成功后才替换旧层。
- Hybrid 与 fallback 都失败时，旧层、CurrentFloor 与进度广播不变。

Renderer 的门与走廊也使用事务式提交：

1. 实例化房间并关闭所有实例 Socket。
2. 解析并去重所有 Connection Socket。
3. 在隐藏暂存 root 中生成走廊和墙。
4. 全部成功后统一开门、激活并命名正式 root。
5. 任一步失败则关闭所有门并丢弃暂存几何。

## DungeonLayout 共享契约

旧系统字段继续保留：

```text
Rooms
FloorCells
StartCell
ExitCell
Seed
```

Hybrid 字段：

```text
HasHybridRoomData
RoomPlacements
RoomCells
CorridorCells
Connections
```

集合关系：

```text
Rooms         = 每个 Placement 旋转后 CellBounds
RoomCells     = 所有 Placement Walkable Global Cells
CorridorCells = 所有 Connection CorridorCells 去重合集
FloorCells    = RoomCells ∪ CorridorCells
```

阶段 8 Manager 必须继续以 `FloorCells` 作为最终可行走权威集合。

## 坐标契约

- 一格等于一个 Unity 世界单位。
- `Cell Size = 1`。
- 整数格坐标表示格子中心。
- `(0,0)` 映射世界 `(0,0,0)`。
- GameManager Transform 不在世界原点，不能把 dungeonRoot.position 当格子零点。
- Prefab 根 Scale 保持 `(1,1,1)`。
- Placement 必须调用 `DreamRoomPlacement.ApplyPose()`。
- Quarter Turns 为顺时针，Unity Z 旋转使用负角度。

## Door Socket 契约

每条 Connection 保存两个房间索引和两个 Socket Id。Renderer 必须在对应房间实例的 `DreamRoomTemplate` 中解析 Socket。

禁止：

```text
placement.Template.SetAllSocketsOpen(...)
```

必须只修改实例组件，不能污染 Prefab Asset。

固定基线：

```text
8 Connections
16 unique opened sockets
28 total instance sockets
12 closed unused sockets
```

## Corridor 渲染契约

- 只遍历 `layout.CorridorCells`。
- Floor Sorting Order 为 -10。
- Corridor Floor 不添加 Collider。
- 墙候选来自八方向边界。
- 墙候选不能属于最终 FloorCells。
- 墙候选不能属于任意房间 Occupied Global Cells。
- 墙去重后生成，Sorting Order 为 0，并添加 BoxCollider2D。
- Shared Corridor Cell 只创建一个 Floor 对象。

## 现有 Manager 依赖

| 系统 | 当前数据 | Stage 7 后状态 |
|---|---|---|
| Player | StartCell + CellToWorld | 已能运行 |
| Exit | ExitCell + CreateSquare | 已能换层 |
| EnemyPathfinder | FloorCells | 数据兼容，实际追踪待 R8.0 |
| EnemySpawner | Rooms 矩形中心 | 灰盒可用，非矩形前需升级 |
| ItemSpawner | Rooms 中心／FloorCells | 灰盒可用，SpawnPoint 待阶段 8 |
| Camera | Player Transform | 已能跟随，R8.0 复核生命周期 |
| Background | RunProgressionContext | 已收到楼层广播，R8.0 复核进度 |

## 阶段 8 边界

R8.0 先做零修改兼容测试。不要因为规划中存在 R8.1–R8.3，就预先改写所有 Manager。通过的旧系统直接保留；只有可复现问题才修改。

