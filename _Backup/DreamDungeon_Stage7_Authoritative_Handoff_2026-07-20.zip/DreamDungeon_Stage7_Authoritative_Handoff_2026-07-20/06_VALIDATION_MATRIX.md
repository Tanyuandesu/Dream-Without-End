# 阶段 7–9 验收矩阵

## 每次脚本交付的固定顺序

1. 退出 Play Mode。
2. 备份将被替换的脚本及其 `.meta`。
3. 只复制交付说明中列出的文件。
4. 等待 Unity 编译完成。
5. Console Clear。
6. 确认无红色错误。
7. 先测试 `ProceduralCells`。
8. 再测试 `HybridPrefabRooms`。
9. 固定 Seed 成功测试。
10. 改 Seed 变化测试。
11. 执行该小修订规定的受控失败测试。
12. 恢复正确参数并再次成功。
13. 保存 Scene 和 Project。

## 阶段 7 必测（已完成，作为冻结回归表）

| 测试 | Procedural | Hybrid | 通过条件 |
|---|---:|---:|---|
| 首层生成 | ✓ | ✓ | 不空白、不报红错 |
| 固定 Seed 重现 | ✓ | ✓ | 同模式布局一致 |
| Seed 变化 | ✓ | ✓ | 布局发生变化 |
| 房间数量 | — | ✓ | 7 个实例 |
| 连接数量 | — | ✓ | 8 条连接 |
| Socket | — | ✓ | 16 个唯一开门 Socket |
| 未用门 | — | ✓ | Blocker 保持 active |
| 门到走廊 | — | ✓ | 无断口、无堵门 |
| 走廊宽度 | — | ✓ | 2 格 |
| 墙碰撞 | ✓ | ✓ | 玩家不能出界 |
| R 重生成 | ✓ | ✓ | 旧 root 清理，新层正常 |
| Exit 下一层 | ✓ | ✓ | 楼层号、地图、相机更新 |
| Hybrid 失败 | — | ✓ | 明确失败／回退，不静默、不空层 |

阶段 7 实际采用两项不污染资产的本地预检注入：

- R7.3 Missing Socket：验证 Connection 门状态全有或全无提交。
- R7.4 Invalid Corridor Cell：验证门与程序化走廊统一事务提交。

两项都已完成失败与恢复测试，最终开关均为关闭。不要再用 Corridor Width 3 代替现有受控失败，也不要在 R8.0 重跑这些注入。

## 阶段 8 必测

| 系统 | 通过条件 |
|---|---|
| Player | 只存在一个玩家；出生格可走；跨层保留 |
| Exit | 位于可走格；Trigger 进入下一层 |
| Enemy Spawn | 不在墙、空洞、Start 或被排除的 Exit 房 |
| Enemy Path | 可跨至少两个房间和一段转弯走廊追踪 |
| Item Spawn | 位于合法 Floor Cell，满足 Start/Exit 距离 |
| Item Progress | 收集数、分数、最后收集层跨层保留 |
| Camera | 首层、R、下一层都重新跟随玩家 |
| Background | 收到楼层／道具进度，不因 Hybrid 中断 |
| UI/Health | 受伤、回血、死亡／复活流程正常 |

受控失败建议：在测试 Prefab 中放一个超出 Walkable Cells 的 SpawnPoint，Template 校验应拒绝；恢复后再次通过。

## 阶段 9 必测

| 数据／内容 | 通过条件 |
|---|---|
| Occupied | 只包含真实房间轮廓，无重复、无越界 |
| Walkable | 属于 Occupied 且不属于 Blocked |
| Blocked | 属于 Occupied；寻路和物理均不可穿 |
| 非矩形旋转 | 四个 Quarter Turns 均正确 |
| Socket | 每个旋转状态仍在边界且门内格可走 |
| SpawnPoint | 旋转后落在对应 Walkable Global Cell |
| Catalog | 楼层、权重、上限和标签规则可解释、可重现 |
| Visual 替换 | 不改变尺寸、门、占格、生成和寻路 |

受控失败建议：把一个 Blocked Cell 放到 Occupied 之外；验证器必须明确指出具体格子。恢复后再次通过。

## 回归停止条件

出现以下任一情况应停止进入下一小修订：

- Console 有新的红色编译／运行错误。
- ProceduralCells 与基线不同。
- Hybrid 实际使用了 fallback，但日志／界面没有说明。
- 固定 Seed 不再可重现。
- Room/Connection/Socket 数量与 Layout 不一致。
- 走廊穿入房间或越出地图。
- 一个已用 Socket 被多条连接重复使用。
- 未使用门打开或已使用门仍封闭。
- `FloorCells` 与真实可行走空间不一致。
- R 或下一层留下旧敌人、旧道具、旧地图对象。

## 截图与日志要求

每个阶段至少保留：

1. GameManager 关键 Inspector。
2. Play Mode Hierarchy 的 GeneratedDungeon 层级。
3. Scene/Game 中完整地图。
4. 成功 Console 日志。
5. 一次受控失败日志。
6. 恢复后再次成功日志。

这些证据应与新源码快照一起进入下一次交接，不要只提供口头“通过”。
