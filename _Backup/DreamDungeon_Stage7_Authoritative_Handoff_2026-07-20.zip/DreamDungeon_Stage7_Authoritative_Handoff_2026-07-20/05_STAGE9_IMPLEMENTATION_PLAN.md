# 阶段 9：非矩形、特殊房与正式内容

## 阶段目标

在矩形灰盒和完整游戏流程稳定后，启用已经预留的数据能力：真实占格、内部障碍、专用房间标签、稀有规则与正式 Visual 替换。

阶段 9 应继续使用阶段 7 的实例化和阶段 8 的 Spawn Resolver，不重写底层生成架构。

## R9.1：制作一个最小非矩形样本

不要一次制作整套内容。先复制一个灰盒 Prefab，制作一个可明显观察的 L 形或带中央空洞的测试房。

在 `DreamRoomTemplate` 中：

- `Occupied Cells`：真实占用的格子。
- `Walkable Cells`：可行走格；空列表表示 Occupied 减 Blocked。
- `Blocked Cells`：内部障碍格，必须属于 Occupied。

校验要求：

- 所有格子位于 `Size In Cells` 范围内。
- 列表内无重复。
- Walkable 属于 Occupied。
- Blocked 属于 Occupied。
- 同一格不能既 Walkable 又 Blocked。
- Socket 的全部门内格必须是可行走边界格。
- SpawnPoint 必须位于 Walkable Cell。

## R9.2：区分“边界框安全”与“真实轮廓利用”

当前 R4 使用旋转后的矩形 `CellBounds + Padding` 判断房间间距。因此非矩形房间可以正确生成、正确寻路和正确渲染，但两个 L 形房间不会互相嵌入空白区域。

建议分两层完成：

1. 首先保留矩形边界放置：实现简单、绝不重叠，是 R9.1 的验收基线。
2. 只有内容确实需要更高密度时，再做 Occupied-Cell-aware Padding。

若实现真实轮廓放置，Padding 不能只检查 Occupied Cells 直接相交；应对每个 Occupied Cell 做指定半径的膨胀后比较，并继续检查地图边界和 Socket 门外空间。

## R9.3：Renderer 对非矩形和内部障碍的职责

房间 Prefab 的 Visual 和 Collider 必须与数据一致：

- 不属于 Occupied 的区域不应有地板或阻挡走廊的墙。
- Blocked Cells 应有对应视觉／碰撞。
- Walkable Cells 应与实际能行走的空间一致。
- Corridor Wall 生成不能填入房间的真实 Occupied Cells。
- 走廊仍不能穿越第三个房间的 Occupied Cells。

数据正确但 Prefab Collider 错误，仍应视为校验失败。建议在阶段 9 增加 Editor 验证器，至少检查已知 Blocked/Walkable 标记与层级对象，而不是依赖肉眼。

## R9.4：RoomTags 正式参与选择

已经存在的 Tags：

- `Standard`
- `StartCandidate`
- `ExitCandidate`
- `Rare`
- `CoreItemCandidate`
- `Special`

推荐启用顺序：

1. Start/Exit 候选限制。
2. Rare 权重与每层上限。
3. Core Item 候选房。
4. Special 唯一房。

规则必须保留回退：若当前楼层没有合格 Start/Exit 模板，使用 Standard 候选并输出一次明确警告，而不是让整层无条件失败。

`MinimumFloor`、`MaximumFloor`、`MaximumInstancesPerFloor` 和 `RandomWeight` 已由 Catalog/R4 使用；不要另建重复字段。

## R9.5：正式美术替换

灰盒 Prefab 是正式骨架，不是一次性测试品。制作正式房间时：

1. 复制一个已通过的灰盒 Prefab。
2. 保留根 `DreamRoomTemplate`。
3. 保留 `Sockets`、Socket Id、方向、门宽和门封块语义。
4. 保留 Navigation／SpawnPoints 数据。
5. 只替换 `Visual` 下的 Floor、Walls、Decoration。
6. Collider 可以随美术调整，但必须与 Occupied/Blocked/门口数据一致。
7. 根 Transform 归零，Rotation 归零，Scale 保持 `(1,1,1)`。
8. 执行 Template 校验。
9. 加入正式 Catalog。
10. 用固定 Seed 做 Hybrid Play Mode 回归。

不要直接修改正在被 Catalog 引用的唯一灰盒资产来试美术；先复制，避免破坏阶段 7 回归基线。

## R9.6：内容规则与进度

在底层稳定后才增加：

- 起始房／出口房专用池。
- 核心道具房。
- 每轮只能出现一次的房间。
- 指定楼层以后出现的房间。
- 随道具进度变化的房间池。
- 稀有记忆房和特殊事件房。

若 Catalog 需要读取整局进度，应通过明确的生成上下文传入，不要让 ScriptableObject 在场景中查找 Manager。

## 阶段 9 验收矩阵

- 一个 L 形房在 0/90/180/270 度下占格正确。
- 中央空洞不进入 `RoomCells` 或 `FloorCells`。
- Blocked Cell 不可寻路、实际也有碰撞。
- Socket 旋转后仍在正确边界且走廊不穿房。
- SpawnPoint 旋转后仍落在正确 Walkable Cell。
- 非矩形房不会与其他房间真实占格重叠。
- ProceduralCells 回退不受影响。
- Graybox Catalog 仍可作为内容故障时的测试基线。
- 替换 Visual 不改变布局、门口、寻路和生成规则。

## 阶段 9 禁止事项

- 不用 Transform 位置代替 Occupied/Walkable 的格子真相。
- 不让美术碰撞与数据长期不一致。
- 不为了一个特殊房在生成器里写 Template Id 硬编码。
- 不在没有回退候选时启用严格标签筛选。
- 不删除灰盒库；它是正式回归测试资产。

