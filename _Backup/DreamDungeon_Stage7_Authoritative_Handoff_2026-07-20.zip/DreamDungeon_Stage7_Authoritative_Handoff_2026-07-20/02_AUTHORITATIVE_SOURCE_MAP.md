# 阶段 7 权威源码地图

## 工程版本

- Unity：`6000.0.26f1 (ccb7c73d2c02)`
- C# 脚本：104 个
- Assets 实际文件：635 个
- Build Scenes：TitleScene、GameScene、EndingScene，均启用

关键 Package：

| Package | Version |
|---|---|
| Universal RP | 17.0.3 |
| Input System | 1.11.2 |
| UGUI | 2.0.0 |
| AI Navigation | 2.0.4 |
| Visual Scripting | 1.9.4 |

## 权威源码 ZIP

| 文件 | 大小 bytes | SHA-256 |
|---|---:|---|
| `SourceProjectSnapshot/Assets.zip` | 12,256,806 | `441c2edd366c6288560c7600d27c5ab1df62d9d4a77a567dc18d7e8c0cbd505a` |
| `SourceProjectSnapshot/Packages.zip` | 1,918 | `81cfd3d11da13ccd775c1825251c6cc7d510f8f8f6b9f8dd93704d19b0ecdfa0` |
| `SourceProjectSnapshot/ProjectSettings.zip` | 19,783 | `e5021ae3c155348aa246003deebd326df1d123a4c38089d05917818f13a35d8c` |

三份 ZIP 均通过完整性检查，并统一包含顶层 `Assets/`、`Packages/`、`ProjectSettings/`。

## 阶段 7 实际代码变化

相对 2026-07-15 R6 权威快照，阶段 7 代码差异严格为：

新增：

```text
Assets/Scripts/Dungeon/HybridRooms/DungeonGenerator.RuntimeHybrid.cs
Assets/Scripts/Dungeon/HybridRooms/DungeonGenerator.RuntimeHybrid.cs.meta
```

替换：

```text
Assets/Scripts/GameManager.cs
Assets/Scripts/Dungeon/HybridRooms/DungeonRenderer.cs
```

对应 `.meta` GUID 保持稳定。没有修改 Packages 或 ProjectSettings。

## 阶段 7 核心哈希

| 文件 | SHA-256 |
|---|---|
| `GameManager.cs` | `c8944a1e837aaee86cf5606b9d6d55f1c048b983a59510609827571995e28097` |
| `DungeonGenerator.RuntimeHybrid.cs` | `c4d5834b7ab2d2069e0628f2e6a1c210d2efd21a87d633b141748f473e7079a5` |
| `DungeonRenderer.cs` | `ebf8098021b98a982f449a074cf0e44ef719b957c065096299c14681e13c32c0` |
| `GameScene.unity` | `9d9a32762b8644699fc929d2e934de99b76a2de3a08e344a75210fb7c53545c5` |

GUID：

```text
GameManager.cs                    51d60c128a42688428e0b7f8993a95fb
DungeonGenerator.RuntimeHybrid.cs 063f70d45669fd1d0ce9cd1382969914
DungeonRenderer.cs                6d0980327b7349e4b89aeb18a8fa3d1d
```

## R0–R6 冻结哈希

| 文件 | SHA-256 |
|---|---|
| `DungeonGenerator.cs` | `4d9811850e05c7c9546f1bacb9111a5904b8e92ad71afc6d4fbbf5921677d2d8` |
| `DungeonLayout.cs` | `80aaa837486debf1596810b6c601b19e62b58d69d7467c82d89a68c0a49438eb` |
| `DungeonGenerator.TemplateFirst.cs` | `ee0625971e9a9b03d29e3533b858572a8b2fe06a646d5f682892a42e69c831ae` |
| `DungeonGenerator.RoomGraph.cs` | `d13c2140b8aa13823b128e3ce35d2ca53ef3f82a7ad8e9d98cd9066606f3aa27` |
| `DungeonGenerator.SocketCorridors.cs` | `affc2e0c45fbbac96924296c4a5ed119bf9b7a31698697b0ee5840f3b055ee4b` |
| `DreamRoomTemplate.cs` | `792e3ea77bfa0a22c4c5ea1336333c67995ecab1e1f298062bd6a37ed0b57274` |
| `DreamRoomPlacement.cs` | `20d813df53f8f62f919de908d771438514fa5175e0209d59cd15d777b25cbe6c` |
| `DreamRoomConnection.cs` | `ba366e69c5d0da991a62861375fbe3d1f7d5c416f104a899913a6199e762c1de` |
| `DreamRoomDoorSocket.cs` | `6aa773cb57faedd3ed9ade8aa221a9ebefff4c167358a0c9b884f0fb27de305d` |

这些哈希与 2026-07-15 权威记录逐字节一致，证明旧 `Generate(int)` 和 R4–R6 没有被阶段 7 改写。

## 灰盒资源哈希

| 资源 | SHA-256 |
|---|---|
| `RoomCatalog_Graybox.asset` | `89e61923840fd86d105c6979106a7c376f66db596444066e212b2ea7de5dd260` |
| `Room_08x06.prefab` | `148a4322ef466696aa85acaab141c0ead5a25eea8741a3b19cb6518a90109e06` |
| `Room_09x16.prefab` | `f610b1f66d344b8d11d3db71b720370fa467f351d80689ebf722258b12dc1298` |
| `Room_13x09.prefab` | `bbb50077076d992e32d0a044755346334c59058de4c71aa96f94e514fd965674` |
| `Room_18x07.prefab` | `8b6c9cbbfb3d0b3fd3e2fd736187ee215034d2187a2ce1d00cac7fef4284e423` |

## Scene 差异说明

相对 R6，GameScene 的阶段 7 相关变化只有：

- `renderMode: 0 → 1`，正式模式改为 Hybrid。
- R7.3/R7.4 失败开关明确序列化为 0。

当前实际快照中 `CircularHealthPanel` 的 Anchored Position 也与 2026-07-15 快照不同。该 UI 位置不属于阶段 7 代码修改；它被保留在完整实际工程快照中，但没有进入阶段 7 代码安装包。

原工程中的 `Assets/Scripts/7_8_backup.zip` 及 `.meta` 已不在当前实际快照。原交接已明确该文件是不可作为基线的历史备份，因此不恢复、不作为运行依赖。

